#Ji Yeon Kim 76016716
#Arash Nabili 37684183
#Raquel Fallman 26316814

from __future__ import division #to avoid division truncation
import math
import pyaudio
import sys

RATE = 44100 #number of frames per second/frameset. 
BPM = 60 #beats per minute
VOLUME = 70 #min 0-127 max
CLEF = "treble" #if clef can be detected in future improvements
MAJOR = "C" #major

def beats2length(beats_list): #returns list of durations given list of beats of 0.5, 1, 2, etc.
	length_list = []
	for beat in beats_list:
		length_list.append((1/(BPM/beat/60))) 
	return length_list

def play_note(note_info, bpm, major): #note info is a list of two-element lists [duration, freq]
	BPM = bpm
	MAJOR = major
    
    #iterating through all the notes and the information (freq, duration) for each note
	for note in note_info:
		freq = note[1] #freq to play
		length =  4/note[0]/(BPM/60) #seconds to play sound

        #altering frequencies depending on the major key (can go up to E major key)
		if (MAJOR == "G") or (MAJOR == "D") or (MAJOR =="A") or (MAJOR =="E") or (MAJOR =="B") or (MAJOR =="F#") or (MAJOR =="C#"):
			if freq == 349.2: #if F4, change to F#4
		 		freq = 370 
			if freq == 698.5: #if F5, change to F#5
				freq = 740
			if (MAJOR == "D") or (MAJOR =="A") or (MAJOR =="E") or (MAJOR =="B") or (MAJOR =="F#") or (MAJOR =="C#"):
				if freq == 261.6:
					freq = 277.2
				if freq == 523.3:
					freq = 554.4
				if (MAJOR =="A") or (MAJOR =="E") or (MAJOR =="B") or (MAJOR =="F#") or (MAJOR =="C#"):
					if freq == 392:
						freq = 415.3
					if freq == 784:
						freq = 830.6
					if (MAJOR =="E") or (MAJOR =="B") or (MAJOR =="F#") or (MAJOR =="C#"):
						if freq == 293.7:
							freq = 311.1
                        if freq == 587.3:
                        	freq = 622.3
               
        #calculate the number of frames                	
		num_frames = int(RATE * length)
		rest_frame = num_frames % RATE
		wave_data = ''    

		#127 is max volume, add 128 to stay in frame range
		for x in xrange(num_frames):
			wave_data = wave_data+chr(int(math.sin(x/((RATE/freq)/(2*math.pi)))*VOLUME+128))    

		#initialize a stream in PyAudio
		p = pyaudio.PyAudio()
		stream = p.open(format = p.get_format_from_width(1), 
		                channels = 1, 
		                rate = RATE, 
		                output = True)
		stream.write(wave_data) #write wave and play
		
	stream.stop_stream()
	stream.close()
	p.terminate()



