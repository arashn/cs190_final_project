Hello,

To run our program, Python should be installed on the machine. 
https://www.python.org/downloads/

Then simply unzip the downloaded folder and follow the instructions given in InstallingPyAudio.txt.

Then using any IDE, run note_analysis.py. (On terminal, cd to path of Group3b_MusicOCR, then type: python note_analysis.py)
Here on the user will be prompted for the name of an image file (e.g. example1.png), the BPM, and the major key (ex: “D”). Our program is default to play treble clef.

PNG files are provided in the folder for the user to input into the program. But if the user wishes to use his or her own file, the image of the staff must be cropped like those shown in example1.png, example2.png, or example3.png. They can be in any file format (e.g., png, jpg) but must be contained in the same directory as note_analysis.py.

Thank you,
Group 3b
Ji Yeon Kim 76016716
Arash Nabili 37684183
Raquel Fallman 26316814